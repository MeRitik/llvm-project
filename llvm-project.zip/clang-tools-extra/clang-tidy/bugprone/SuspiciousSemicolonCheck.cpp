//===----------------------------------------------------------------------===//
//
// Part of the LLVM Project, under the Apache License v2.0 with LLVM Exceptions.
// See https://llvm.org/LICENSE.txt for license information.
// SPDX-License-Identifier: Apache-2.0 WITH LLVM-exception
//
//===----------------------------------------------------------------------===//

#include "SuspiciousSemicolonCheck.h"
#include "../utils/LexerUtils.h"
#include "clang/AST/ASTContext.h"
#include "clang/ASTMatchers/ASTMatchFinder.h"

using namespace clang::ast_matchers;

namespace clang::tidy::bugprone {

void SuspiciousSemicolonCheck::registerMatchers(MatchFinder *Finder) {
  Finder->addMatcher(ifStmt(hasThen(nullStmt().bind("semi")),
                            unless(hasElse(stmt())), unless(isConstexpr()))
                         .bind("stmt"),
                     this);
  Finder->addMatcher(forStmt(hasBody(nullStmt().bind("semi"))).bind("stmt"),
                     this);
  Finder->addMatcher(
      cxxForRangeStmt(hasBody(nullStmt().bind("semi"))).bind("stmt"), this);
  Finder->addMatcher(whileStmt(hasBody(nullStmt().bind("semi"))).bind("stmt"),
                     this);
}

void SuspiciousSemicolonCheck::check(const MatchFinder::MatchResult &Result) {
  if (Result.Context->getDiagnostics().hasUncompilableErrorOccurred())
    return;

  const auto *Semicolon = Result.Nodes.getNodeAs<NullStmt>("semi");
  const SourceLocation LocStart = Semicolon->getBeginLoc();

  if (LocStart.isMacroID())
    return;

  ASTContext &Ctxt = *Result.Context;
  const auto &SM = *Result.SourceManager;
  const unsigned SemicolonLine = SM.getSpellingLineNumber(LocStart);

  const auto *Statement = Result.Nodes.getNodeAs<Stmt>("stmt");
  const bool IsIfStmt = isa<IfStmt>(Statement);

  const std::optional<Token> PrevTok = utils::lexer::getPreviousToken(
      LocStart, Ctxt.getSourceManager(), Ctxt.getLangOpts());
  if (!PrevTok || (!IsIfStmt && SM.getSpellingLineNumber(
                                    PrevTok->getLocation()) != SemicolonLine))
    return;

  const SourceLocation LocEnd = Semicolon->getEndLoc();
  const FileID FID = SM.getFileID(LocEnd);
  const llvm::MemoryBufferRef Buffer = SM.getBufferOrFake(FID, LocEnd);
  Lexer Lexer(SM.getLocForStartOfFile(FID), Ctxt.getLangOpts(),
              Buffer.getBufferStart(), SM.getCharacterData(LocEnd) + 1,
              Buffer.getBufferEnd());
  Token Token;
  if (Lexer.LexFromRawLexer(Token))
    return;

  const unsigned BaseIndent =
      SM.getSpellingColumnNumber(Statement->getBeginLoc());
  const unsigned NewTokenIndent =
      SM.getSpellingColumnNumber(Token.getLocation());
  const unsigned NewTokenLine = SM.getSpellingLineNumber(Token.getLocation());

  if (!IsIfStmt && NewTokenIndent <= BaseIndent &&
      Token.getKind() != tok::l_brace && NewTokenLine != SemicolonLine)
    return;

  diag(LocStart, "potentially unintended semicolon")
      << FixItHint::CreateRemoval(SourceRange(LocStart, LocEnd));
}

} // namespace clang::tidy::bugprone
